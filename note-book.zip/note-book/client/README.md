1. 初始化样式 (大项目最好 npm i less -D )
2. 修改根字体大小
3. element-ui仅限PC端使用，移动端用 https://vant-ui.github.io/vant/#/zh-CN