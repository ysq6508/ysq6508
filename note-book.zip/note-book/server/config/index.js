const config = {
    database: {
        DATABASE: 'note-book',
        USERNAME: 'root',
        PASSWORD: 'yan525712@',
        PORT: '3306',
        HOST: 'localhost'
    }
}

module.exports = config